1. How to run thr program?
- This is simple java application. I used gradle to include all the dependencies. Mainly JUNIT dependencies are added to implement some unit test cases
- To run the program
    - download the zip file
    - unzip to folder
    - open project folder in IDE of your choice
    - Run main class Main.java
    - All files required for program are added in resources folder
2. What has been tested?
- Unit tests are written in ContentMatcherTest.java class
- In unit test, best case scenario is tested to make sure program is returning output as expected

Assumption
1. Input file has words separated by single space