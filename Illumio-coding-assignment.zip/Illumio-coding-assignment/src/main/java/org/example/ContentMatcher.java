package org.example;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class ContentMatcher {
    private static final String NEWLINE = "\n";
    private static final String SPACE_SEPRATED_STRING = " ";
    private static final String EMPTY_STRING = "";
    private static final String SLASH = "/";
    private static final String NON_ALPHANUMERIC_REGEX = "[^a-zA-Z]";
    private String contentFileName;
    private String wordsFileName;


    public ContentMatcher(String contentFileName, String wordsFileName) {
        this.contentFileName = contentFileName;
        this.wordsFileName = wordsFileName;
    }

    /**
     * Method to find matching words from wordsFile with contentFile.
     * @return Map representing matched string and its frequency.
     */
    public Map<String, Integer> findMatch() {
        String contentString = readFile(contentFileName);
        String wordFileString = readFile(wordsFileName);
        List<String> wordList = Arrays.stream(wordFileString.split(NEWLINE)).collect(Collectors.toList());
        List<String> contentList = Arrays.stream(contentString.split(NEWLINE)).collect(Collectors.toList());
        return findMatchHelper(wordList, contentList);
    }

    /**
     * Method to create map that represents matched string and its frequency.
     * @param wordList list of string from predefined words file.
     * @param contentList list of string from text file with all the content.
     * @return Map representing matched string and its frequency.
     */
    private Map<String, Integer> findMatchHelper(List<String> wordList, List<String> contentList) {
        Map<String, Integer> res = new HashMap<>();
        contentList.stream()
                .flatMap(content -> Arrays.stream(content.split(SPACE_SEPRATED_STRING)))
                .map(word -> word.replaceAll(NON_ALPHANUMERIC_REGEX, EMPTY_STRING))
                .map(String::toLowerCase)
                .forEach(word -> {
                    wordList.stream()
                            .filter(preDefWord -> preDefWord.equalsIgnoreCase(word))
                            .forEach(preDefWord -> res.put(preDefWord, res.getOrDefault(preDefWord, 0) + 1));
                });
        return res;
    }

    /**
     * Read file.
     * @param fileName name of the file.
     * @return string representation of the file.
     */
    private String readFile(String fileName) {
        InputStream inputStream = ContentMatcher.class.getResourceAsStream(SLASH+fileName);
        String string = new BufferedReader(
                new InputStreamReader(inputStream, StandardCharsets.UTF_8))
                .lines()
                .collect(Collectors.joining("\n"));
        return  string;
    }


}
