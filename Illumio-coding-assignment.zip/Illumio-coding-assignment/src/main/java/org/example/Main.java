package org.example;

import java.util.Map;

public class Main {

    public static void main(String[] args) {
        ContentMatcher contentMatcher = new ContentMatcher("ContentFile.txt", "WordsFile.txt");
        Map<String, Integer> result = contentMatcher.findMatch();
        result.forEach((k, v) -> System.out.println(k + ": " + v));
    }
}