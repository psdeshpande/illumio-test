package org.example;

import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Map;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContentMatcherTest {
    private static final String CONTENT_FILE_NAME = "ContentFile.txt";
    private static final String WORDS_FILE_NAME = "WordsFile.txt";

    @BeforeEach
    void setUp() throws IOException {
        // Create test content file
        try (FileWriter contentWriter = new FileWriter(new File(getClass().getResource("/").getPath() + CONTENT_FILE_NAME))) {
            contentWriter.write("FirstName LastName Zipcode\n");
            contentWriter.write("FirstName Zipcode\n");
            contentWriter.write("firstname zipcode.\n");
        }
        // Create test words file
        try (FileWriter wordsWriter = new FileWriter(new File(getClass().getResource("/").getPath() + WORDS_FILE_NAME))) {
            wordsWriter.write("FirstName\n");
            wordsWriter.write("LastName\n");
            wordsWriter.write("Zipcode\n");
        }
    }

    @Test
    public void testFindMatch() {
        ContentMatcher contentMatcher = new ContentMatcher(CONTENT_FILE_NAME, WORDS_FILE_NAME);
        Map<String, Integer> result = contentMatcher.findMatch();

        assertEquals(3, result.get("FirstName"));
        assertEquals(1, result.get("LastName"));
        assertEquals(3, result.get("Zipcode"));
    }

    @AfterEach
    void tearDown() {
    }
}